#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

void displayClock(int hours, int minutes, int seconds) {

    cout << "24-Hour: "; // 24 hour
    cout << setw(2) << setfill('0') << hours << ":" // display hours
        << setw(2) << setfill('0') << minutes << ":" // display minutes
        << setw(2) << setfill('0') << seconds << endl; // display seconds

    int displayHours = hours % 12; // 12 hour
    if (displayHours == 0) displayHours = 12;
    string period = (hours < 12) ? "AM" : "PM"; // display proper 12 hour clock , two sets of 1-12 hours, am & pm
    cout << "12-Hour: "; // 12 hour
    cout << setw(2) << setfill('0') << displayHours << ":" // display hours 
        << setw(2) << setfill('0') << minutes << ":" // display minutes
        << setw(2) << setfill('0') << seconds << " " << period << endl; // display seconds
}

int main() {
    int hours, minutes, seconds;
    cout << "Enter initial time (hours minutes seconds): "; // ask user for unput
    cin >> hours >> minutes >> seconds;

    bool running = true;

    while (running) {
        displayClock(hours, minutes, seconds);
        // display menu
        cout << "\nMenu:\n";
        cout << "1. Add One Hour\n";
        cout << "2. Add One Minute\n";
        cout << "3. Add One Second\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        int choice; // declare choice option
        cin >> choice; // pick choice

        if (choice == 1) { // if 1 add 1 to user's hour input
            hours = (hours + 1) % 24; // keeps hour no larger than 24
        }
        else if (choice == 2) { //add minute
            minutes = (minutes + 1) % 60; // add to user's minute input and make sure no larger than 60 minutes
            if (minutes == 0) {
                hours = (hours + 1) % 24; // if it does, increase the hour
            }
        }
        else if (choice == 3) { // add second
            seconds = (seconds + 1) % 60; // add second to user's seconds input and doesn't exceed 60 seconds
            if (seconds == 0) { 
                minutes = (minutes + 1) % 60; // increase minutes
                if (minutes == 0) {
                    hours = (hours + 1) % 24; // increase hour
                }
            }
        }
        else if (choice == 4) { // exit program choice
            cout << "Exiting program" << endl;
            running = false;
        }
        else {
            cout << "Invalid input, try again." << endl;
        }
    }

    return 0;
}